use Films
go

--- Important Note: Please make sure to change the paths for Excel import/export and backups.

------------------insert  excel-------------------------------------
--explaintion: we import from csv to table "views" another 200 views 

--insert from csv
BULK INSERT [dbo].[Views]
FROM 'C:\\final_Project_sql\\views_data.csv'   
WITH 
( 
    CODEPAGE = 'ACP',  -- Enable Hebrew (Assuming ACP supports it)
    FIRSTROW = 2,  -- Skip the header row
    MAXERRORS = 0,  -- Fail on any error
    FIELDTERMINATOR = ',', -- Field separator
    ROWTERMINATOR = '\n'  -- New line separator
)
GO

select * from Views
go

-------------------------------------------------------------------------------------------------


--------updates---------------------------------------------------------
--update the views table - if vip he doesnt pay about the popcorn,drin and ice cream
UPDATE Views
SET popcorn_size = NULL,
    drink_size = NULL,
    ice_cream= NULL
WHERE hall = 'vip';
go

select * from Views
order by customer_id
go


-- Update the NumOfWatchedMovies column in the Customers table
--the original table havd "fake" values in column "NumOfWatchedMovies" so we want to fix it
UPDATE Customers
SET NumOfWatchedMovies = COALESCE(ViewCounts.NumOfViews, 0)
FROM Customers
LEFT JOIN (
    SELECT customer_id, COUNT(*) AS NumOfViews
    FROM Views
    GROUP BY customer_id) ViewCounts ON Customers.customer_id = ViewCounts.customer_id

--COALESCE(ViewCounts.NumOfViews, 0) ensures that if there are no views for a customer, the NumOfWatchedMovies is set to 0 instead of NULL.
go

select * from Customers
go
----------------------------------------------------------------------

--------------------create new column in table Branches: "total views"-------------------------------------------------------------
--show how much were in each branch of cinema 
ALTER TABLE Branches
ADD total_views INT
go

UPDATE Branches
SET total_views = (SELECT COUNT(Views.view_id)
                   FROM Views
                   WHERE Views.branch_id = Branches.branch_id);
go

SELECT * FROM Branches
go
------------------------------------------------------------------------------------


--------------------view most watched movies and export to excel-------------------------------
--View that show the movies that have more than 9 views.
CREATE or alter VIEW Most_Watched_Movies
AS
SELECT Movies.movie_id, Movies.name AS movie_name, Genres.genre_name, COUNT(Views.view_id) AS view_count
FROM Views
INNER JOIN Movies ON Views.movie_id = Movies.movie_id
INNER JOIN Genres ON Movies.genre_id = Genres.genre_id
GROUP BY Movies.movie_id, Movies.name, Genres.genre_name
HAVING COUNT(Views.view_id) > 9
go

---View that show the number of viewers for each genre in the Most_Watched_Movies view
CREATE or alter VIEW Most_Watched_Movies_by_Genre
AS
SELECT genre_name, SUM(view_count) AS total_view_count
FROM Most_Watched_Movies
GROUP BY genre_name
GO

select * from Most_Watched_Movies_by_Genre
order by total_view_count desc
go

-----export to excel
--explantion: we want to show which genre is the most watched (from the most watched movies)
exec sp_configure 'show advanced options',1
reconfigure 
GO
sp_configure 'xp_cmdshell','1'
reconfigure with override
GO

Declare @View_name varchar(100)
Declare @File_name varchar(100)
Declare @command varchar(200)
SET @View_name = 'Most_Watched_Movies_by_Genre';
SET @File_name = 'C:\final_Project_sql\' + @View_name + '.xls';  -- Ensure the directory exists and is writable
SET @command = 'bcp ' + db_name() + '.dbo.' + @View_name + ' out "' + @File_name + '" -c -T -S "LAPTOP-I6MIKPSL\SQLEXPRESS"';

PRINT @command;

EXEC xp_cmdshell @command;
GO
---------------------------------------------------------------------------------------


-----------------------show movies income from higest to lowest------------------------------------------------
--show details about the movies order by income from the higher to lower
SELECT name,genre_name, dbo.Directors.firstName +' '+ dbo.Directors.lastName as "Director",release_year, dbo.MainActors.first_name+' '+dbo.MainActors.last_name as "Main actor", income as "Income in milions $"
FROM   dbo.Directors INNER JOIN dbo.Movies ON
								dbo.Directors.director_id = dbo.Movies.director_id INNER JOIN dbo.Genres ON 
																	dbo.Movies.genre_id = dbo.Genres.genre_id INNER JOIN  dbo.MainActors ON 
																										dbo.Movies.actor_id = dbo.MainActors.actor_id
order by income desc
GO
----------------------------------------------------------------------------------------------------------------

-----------------------------create column "VIP customer" in table customers------------------------------------

--show details about the customers to show who were the customers that saw the most number of movies 
SELECT customer_id, dbo.Customers.first_name+' '+dbo.Customers.last_name as "Customer name",Customers.age,Movies.name as "favorite movie",genre_name as "favorite genre", dbo.MainActors.first_name+' '+dbo.MainActors.last_name AS "favorite actor",NumOfWatchedMovies
FROM            dbo.Customers INNER JOIN dbo.Movies ON
						dbo.Customers.favorite_movie = dbo.Movies.movie_id INNER JOIN dbo.Genres ON
									dbo.Customers.favorite_genre = dbo.Genres.genre_id INNER JOIN dbo.MainActors ON
											dbo.Customers.favorite_actor = dbo.MainActors.actor_id 
order by NumOfWatchedMovies desc
GO

--create new column in Customers to check if the Customer is vip or not
ALTER TABLE Customers
ADD Vip_status int
go


--function that check if NumOfWatchedMovies>5 foreach customer, if "true" change the "VIP status" to 1 else to 0
CREATE or alter FUNCTION CheckVipStatus (@NumOfWatchedMovies INT)
RETURNS BIT
AS
BEGIN
    RETURN CASE
        WHEN @NumOfWatchedMovies > 5 THEN 1
        ELSE 0
    END;
END;
go

UPDATE Customers
SET Vip_status = dbo.CheckVipStatus(NumOfWatchedMovies);
go

select * from Customers
order by NumOfWatchedMovies desc
go
--------------------------------------------------------------------------------------------------------------------------------------


--------------create N tables foreach cinema to show the viewers and how much they paid------------------------------------------------------------------------------

--show details about evrey viewer - which movie saw and where,what he buy and how much it cost
create or alter view view_details
as
SELECT v.view_id,c.customer_id,c.first_name + ' ' + c.last_name AS "customer name",c.Vip_status,m.name AS "movie",b.name AS "cinema branch",ci.name as "cinema",v.popcorn_size,v.drink_size,
		CASE v.ice_cream 
        WHEN 1 THEN 'buy'
        ELSE 'doesn''t buy'
    END AS ice_cream_status,v.hall,
    (
        CASE v.popcorn_size 
            WHEN 'small' THEN ci.small_popcorn_price
            WHEN 'medium' THEN ci.medium_popcorn_price
            WHEN 'large' THEN ci.large_popcorn_price
            ELSE 0 
        END 
        + CASE v.drink_size 
            WHEN 'small' THEN ci.small_drink_price
            WHEN 'medium' THEN ci.medium_drink_price
            WHEN 'large' THEN ci.large_drink_price
            ELSE 0 
        END 
        + CASE v.ice_cream 
            WHEN 1 THEN ci.ice_cream_price
            ELSE 0 
        END 
        + CASE v.hall 
            WHEN 'vip' THEN ci.vip_ticket_price
            WHEN 'regular' THEN ci.regular_ticket_price
            ELSE 0 
        END
    ) AS total_payment
FROM dbo.Customers c INNER JOIN dbo.Views v 
			ON c.customer_id = v.customer_id INNER JOIN dbo.Movies m ON
					v.movie_id = m.movie_id INNER JOIN dbo.Branches b ON
							v.branch_id = b.branch_id INNER JOIN dbo.Cinemas ci ON
									b.cinema_id = ci.cinema_id
go

--show all the views with their details
select * from view_details
go

--create proc that show the details about specific customer
create or alter PROCEDURE GetCustomerViewDetails
    @CustomerID INT
AS
BEGIN
    SELECT *
    FROM view_details
    WHERE customer_id = @CustomerID;
END
go

EXEC GetCustomerViewDetails @CustomerID = 222
GO

--create N new tables foreach "cinema" by using proc
CREATE or alter PROC CreateCinemaTable
    @CinemaName NVARCHAR(100)
AS
BEGIN
    DECLARE @TableName NVARCHAR(128);
    SET @TableName = 'Cinema_' + REPLACE(@CinemaName, ' ', '_');

    DECLARE @table NVARCHAR(250);
    SET @table = '
        IF OBJECT_ID(''' + @TableName + ''') IS NOT NULL
        DROP TABLE ' + @TableName + ';

        SELECT *
        INTO ' + @TableName + '
        FROM view_details
        WHERE [cinema] = @CinemaName;
    ';

    EXEC sp_executesql @table, N'@CinemaName NVARCHAR(100)', @CinemaName;
END;
GO

DECLARE @CinemaName NVARCHAR(100)
DECLARE CinemaCursor CURSOR FOR
SELECT [name] FROM cinemas;

OPEN CinemaCursor;
FETCH NEXT FROM CinemaCursor INTO @CinemaName;

WHILE @@FETCH_STATUS = 0
BEGIN
    EXEC CreateCinemaTable @CinemaName = @CinemaName;
    FETCH NEXT FROM CinemaCursor INTO @CinemaName;
END;

CLOSE CinemaCursor;
DEALLOCATE CinemaCursor;
go

---Example for new table GetCustomerViewDetails
select * from Cinema_Lev_Cinema
go

---------------------------------------------------------------------------------------------------------------------------------

-----------cinemas income and export to excel------------------------------------------

--View that show the details of cinemas income.
CREATE OR ALTER VIEW Cinema_Summary AS
SELECT 'Cinema City' AS "Cinema Name", COUNT(view_id) AS "Total views", SUM(total_payment) AS "Total income",AVG(total_payment) AS "Avgrage Income"
FROM Cinema_Cinema_City

UNION ALL
SELECT 'Hot Cinema' AS "Cinema Name", COUNT(view_id) AS "Total views", SUM(total_payment) AS "Total income", AVG(total_payment) AS "Avgrage Income"
FROM Cinema_Hot_Cinema
UNION ALL

SELECT 'Lev Cinema' AS "Cinema Name",COUNT(view_id) AS "Total views",SUM(total_payment) AS "Total income",AVG(total_payment) AS "Avgrage Income"
FROM Cinema_Lev_Cinema

UNION ALL
SELECT 'Movieland' AS "Cinema Name",COUNT(view_id) AS "Total views", SUM(total_payment) AS "Total income",AVG(total_payment) AS "Avgrage Income"
FROM Cinema_Movieland;
go
--show how nuch was in each cinema and his total and avg income 
select * from Cinema_Summary
go

--export to excel
--explantion: we want to show the Distribution of total income by cinema and to see the incomes and how many people comes to each 1 of them
exec sp_configure 'show advanced options',1
reconfigure 
GO
sp_configure 'xp_cmdshell','1'
reconfigure with override
GO

Declare @View_name varchar(50)
Declare @File_name varchar(50)
Declare @command varchar(200)
SET @View_name = 'Cinema_Summary';
SET @File_name = 'C:\final_Project_sql\' + @View_name + '.xls';  -- Ensure the directory exists and is writable
SET @command = 'bcp ' + db_name() + '.dbo.' + @View_name + ' out "' + @File_name + '" -c -T -S "LAPTOP-I6MIKPSL\SQLEXPRESS"';

PRINT @command;

EXEC xp_cmdshell @command;
GO
---------------------------------------------------------------------------------------------------------------


------------------- Updating cinema prices (with transaction)-----------------------------------
CREATE OR ALTER PROCEDURE UpdateCinemaPrices
    @cinema_id INT,
    @regular_ticket_price INT,
    @vip_ticket_price INT,
    @small_popcorn_price INT,
    @medium_popcorn_price INT,
    @large_popcorn_price INT,
    @small_drink_price INT,
    @medium_drink_price INT,
    @large_drink_price INT
AS
BEGIN TRANSACTION;

    UPDATE Cinemas
    SET regular_ticket_price = @regular_ticket_price,
        vip_ticket_price = @vip_ticket_price,
        small_popcorn_price = @small_popcorn_price,
        medium_popcorn_price = @medium_popcorn_price,
        large_popcorn_price = @large_popcorn_price,
        small_drink_price = @small_drink_price,
        medium_drink_price = @medium_drink_price,
        large_drink_price = @large_drink_price
    WHERE cinema_id = @cinema_id;

    IF @@ERROR <> 0
    BEGIN
        PRINT 'Error occurred while updating prices. Rolling back transaction.';
        ROLLBACK TRANSACTION;
        RETURN;
    END

    PRINT 'Prices updated successfully.';
    COMMIT TRANSACTION;
go

--run 2 select together to see the diffrence
select * from Cinemas

EXEC UpdateCinemaPrices    @cinema_id = 10000,@regular_ticket_price = 50,@vip_ticket_price = 135,
						   @small_popcorn_price = 22,@medium_popcorn_price = 29,@large_popcorn_price = 30,
						   @small_drink_price = 16,@medium_drink_price = 20,@large_drink_price = 23;
go

select * from Cinemas
go
--------------------------------------------------------------------------------------------------------------


-----Create proc that delete the customer and all his views from table "views" and from the 4 tables that we created for each cinema (with transaction)

CREATE OR ALTER PROCEDURE DeleteCustomerAndViews
    @customer_id INT
AS
BEGIN
    DECLARE @error_occurred BIT = 0;

    BEGIN TRANSACTION;

    DECLARE @exists_cinema_city BIT = 0;
    DECLARE @exists_hot_cinema BIT = 0;
    DECLARE @exists_lev_cinema BIT = 0;
    DECLARE @exists_movieland BIT = 0;

    SELECT @exists_cinema_city = 1
    FROM Cinema_Cinema_City
    WHERE customer_id = @customer_id;

    SELECT @exists_hot_cinema = 1
    FROM Cinema_Hot_Cinema
    WHERE customer_id = @customer_id;

    SELECT @exists_lev_cinema = 1
    FROM Cinema_Lev_Cinema
    WHERE customer_id = @customer_id;

    SELECT @exists_movieland = 1
    FROM Cinema_Movieland
    WHERE customer_id = @customer_id;

    IF @exists_cinema_city = 0 AND @exists_hot_cinema = 0 AND @exists_lev_cinema = 0 AND @exists_movieland = 0
    BEGIN
        PRINT 'Customer does not exist in any cinema-related tables.';
        SET @error_occurred = 1;
    END
    ELSE
    BEGIN
       
        DELETE FROM Views
        WHERE customer_id = @customer_id;

        IF @@ROWCOUNT = 0
        BEGIN
            PRINT 'No views found for the specified customer.';
            SET @error_occurred = 1;
        END
        ELSE
        BEGIN
            PRINT 'Views deleted successfully.';
        END

        IF @exists_cinema_city = 1
        BEGIN
            DELETE FROM Cinema_Cinema_City
            WHERE customer_id = @customer_id;

            IF @@ROWCOUNT > 0
            BEGIN
                PRINT 'Customer deleted from Cinema_Cinema_City.';
            END
        END

        IF @exists_hot_cinema = 1
        BEGIN
            DELETE FROM Cinema_Hot_Cinema
            WHERE customer_id = @customer_id;

            IF @@ROWCOUNT > 0
            BEGIN
                PRINT 'Customer deleted from Cinema_Hot_Cinema.';
            END
        END

        IF @exists_lev_cinema = 1
        BEGIN
            DELETE FROM Cinema_Lev_Cinema
            WHERE customer_id = @customer_id;

            IF @@ROWCOUNT > 0
            BEGIN
                PRINT 'Customer deleted from Cinema_Lev_Cinema.';
            END
        END

        IF @exists_movieland = 1
        BEGIN
            DELETE FROM Cinema_Movieland
            WHERE customer_id = @customer_id;

            IF @@ROWCOUNT > 0
            BEGIN
                PRINT 'Customer deleted from Cinema_Movieland.';
            END
        END
    END

    DELETE FROM Customers
    WHERE customer_id = @customer_id;

    IF @@ROWCOUNT = 0
    BEGIN
        PRINT 'Customer record not found to delete from Customers table.';
        SET @error_occurred = 1;
    END
    ELSE
    BEGIN
        PRINT 'Customer deleted from Customers table.';
    END

    IF @error_occurred = 1
    BEGIN
        ROLLBACK TRANSACTION;
        PRINT 'Transaction rolled back.';
    END
    ELSE
    BEGIN
        COMMIT TRANSACTION;
        PRINT 'Customer and associated records deleted successfully.';
    END
END;

EXEC DeleteCustomerAndViews @customer_id = 204;

--the results of the tables
select * from Customers
select * from Views
where customer_id=204
select * from Cinema_Cinema_City
where customer_id=204
select * from Cinema_Hot_Cinema
where customer_id=204
select * from Cinema_Lev_Cinema
where customer_id=204
select * from Cinema_Movieland
where customer_id=204
go
------------------------------------------------------------------------------------------------------

-----create Multi-Statement Function that return the name of the genre the user select and his avarge income------
CREATE or alter FUNCTION dbo.AvgIncomeAndGenreName (@GenreID INT)
RETURNS TABLE
AS
RETURN
(
    SELECT G.genre_name,AVG(M.income) AS "Avg Income in milions of $"
    FROM Movies M INNER JOIN Genres G
			ON M.genre_id = G.genre_id
    WHERE G.genre_id = @GenreID
    GROUP BY G.genre_name
)
go

SELECT * 
FROM dbo.AvgIncomeAndGenreName(3); 
go
----------------------------------------------------------------------------------------------------------


-- Create Multi-Statement function to get movies watched by a customer include genre name-----------------
CREATE OR ALTER FUNCTION dbo.GetMoviesWatchedByCustomer (@CustomerID INT)
RETURNS @Movies TABLE
(
    name VARCHAR(255),
    genre_name VARCHAR(100),
    release_year INT
)
AS
BEGIN
    INSERT INTO @Movies (name, genre_name, release_year)
    SELECT M.name, G.genre_name, M.release_year
    FROM Movies M
    JOIN Views V ON M.movie_id = V.movie_id
    JOIN Genres G ON M.genre_id = G.genre_id
    WHERE V.customer_id = @CustomerID;

    RETURN
END
go

DECLARE @CustomerID INT
SET @CustomerID = 222
SELECT * FROM dbo.GetMoviesWatchedByCustomer(@CustomerID)
go
---------------------------------------------------------------------------------------------------


----------------------------------------------------------------------------------------------------
-- create proc that get an genre and return with output the number of movies from this genre
--if the genre not exists it will print 'No movies found for the specified genre'
CREATE OR ALTER PROCEDURE CountMoviesByGenre
(
    @GenreID INT,
    @MovieCount INT OUTPUT
)
AS
BEGIN
    SET @MovieCount = 0;
    DECLARE @Movies TABLE
    (
        movie_id INT
    );

    INSERT INTO @Movies (movie_id)
    SELECT movie_id
    FROM Movies
    WHERE genre_id = @GenreID;

    IF EXISTS (SELECT 1 FROM @Movies)
    BEGIN     
        WHILE EXISTS (SELECT 1 FROM @Movies)
        BEGIN
            SET @MovieCount = @MovieCount + 1;
            DELETE FROM @Movies
            WHERE movie_id = (SELECT TOP (1) movie_id FROM @Movies);
        END;
        PRINT 'Number of movies in genre ' + CAST(@GenreID AS VARCHAR(10)) + ': ' + CAST(@MovieCount AS VARCHAR(10));
    END
    ELSE
    BEGIN
        PRINT 'No movies found for the specified genre.';
    END;
END;
go

DECLARE @GenreID INT;
DECLARE @MovieCount INT;
SET @GenreID = 8; 
EXEC dbo.CountMoviesByGenre @GenreID, @MovieCount OUTPUT;
SELECT @MovieCount AS MovieCount;
go
----------------------------------------------------------------------------------------------------



------------------------details of payment in branches---------------------------------------------

------create function that get from the user cinema and return the most profitable branch of this cinema-----
CREATE OR ALTER FUNCTION GetMostProfitableBranch
(
    @CinemaName NVARCHAR(100)
)
RETURNS TABLE
AS
RETURN
(
    SELECT TOP 1 [cinema branch],SUM(total_payment) AS total_revenue
    FROM
    (
        SELECT [cinema branch], total_payment 
        FROM Cinema_Cinema_City
        WHERE @CinemaName = 'Cinema City'
       
        UNION ALL
        
        SELECT [cinema branch], total_payment 
        FROM Cinema_Hot_Cinema
        WHERE @CinemaName = 'Hot Cinema'
        
        UNION ALL
        
        SELECT [cinema branch], total_payment 
        FROM Cinema_Movieland
        WHERE @CinemaName = 'Movieland'
        
        UNION ALL
        
        SELECT [cinema branch], total_payment 
        FROM Cinema_Lev_Cinema
        WHERE @CinemaName = 'Lev Cinema'
    ) AS Combined
    GROUP BY [cinema branch]
    ORDER BY total_revenue DESC
);
go

SELECT * FROM GetMostProfitableBranch('Lev Cinema');
GO

-------function that show the AVG payment for movie at the branch that the user put-------
CREATE or alter FUNCTION dbo.AveragePayment(@branch NVARCHAR(50))
RETURNS DECIMAL(10, 2)
AS
BEGIN
    DECLARE @AvgPayment DECIMAL(10, 2);

    SELECT @AvgPayment = AVG(total_payment)
    FROM (
        SELECT total_payment FROM Cinema_Cinema_City WHERE [cinema branch] = @branch
        UNION ALL
        SELECT total_payment FROM Cinema_Hot_Cinema WHERE [cinema branch] = @branch
        UNION ALL
        SELECT total_payment FROM Cinema_Lev_Cinema WHERE [cinema branch] = @branch
        UNION ALL
        SELECT total_payment FROM Cinema_Movieland WHERE [cinema branch] = @branch
    ) AS CombinedPayments;

    RETURN ISNULL(@AvgPayment, 0.00);
END;
go

DECLARE @Average DECIMAL(10, 2);
SET @Average = dbo.AveragePayment('Lev Cinema Omer');
PRINT 'Average payment: ' + CAST(@Average AS NVARCHAR(10));
GO
-------------------------------------------------------------------------------------------

--------------- Function to calculate discount --------------------------------------------

-- Function that calculates the discount
CREATE OR ALTER FUNCTION dbo.CalculateDiscount
(
    @Amount DECIMAL(10, 2)
)
RETURNS DECIMAL(10, 2)
AS
BEGIN
    DECLARE @Discount DECIMAL(10, 2);
    
    SET @Discount = @Amount * 0.10;
    
    RETURN @Discount;
END;
GO

-- Function to calculate final price after discount
CREATE OR ALTER FUNCTION dbo.CalculateFinalPrice
(
    @OriginalPrice DECIMAL(10, 2)
)
RETURNS DECIMAL(10, 2)
AS
BEGIN
    DECLARE @Discount DECIMAL(10, 2);
    DECLARE @FinalPrice DECIMAL(10, 2);
    
    SET @Discount = dbo.CalculateDiscount(@OriginalPrice);
    SET @FinalPrice = @OriginalPrice - @Discount;
    
    RETURN @FinalPrice;
END;
GO

-- Function to calculate final price based on customer VIP status
CREATE OR ALTER FUNCTION dbo.CalculateFinalPriceForCustomer
(
    @CustomerID INT,
    @TotalPayment DECIMAL(10, 2)
)
RETURNS DECIMAL(10, 2)
AS
BEGIN
    DECLARE @FinalPrice DECIMAL(10, 2);
    DECLARE @VipStatus BIT;
	
    -- Check if the customer is a VIP
    SELECT @VipStatus = Vip_status
    FROM customers 
    WHERE customer_id = @CustomerID ;

    -- Calculate final price based on VIP status
    IF @VipStatus = 1
    BEGIN
        -- Apply discount if VIP
        SET @FinalPrice = dbo.CalculateFinalPrice(@TotalPayment);
    END
    ELSE
    BEGIN
        -- No discount if not VIP
        SET @FinalPrice = @TotalPayment;
    END

    RETURN @FinalPrice;
END;
GO

-- Find the last view (the row that was inserted last)
CREATE OR ALTER FUNCTION dbo.maxView()
RETURNS int
as
begin
	return (select max(view_id) from Views)
end
go


--Save the last "view" that was inserted in a new view, if the viewer is a VIP he will receive a discount. Then, update the final price. 
CREATE OR ALTER VIEW view_details2
AS
SELECT v.view_id,c.customer_id,c.first_name + ' ' + c.last_name AS "customer name",m.name AS "movie",b.name AS "cinema branch",ci.name AS "cinema",
    v.popcorn_size,v.drink_size,
    CASE v.ice_cream 
        WHEN 1 THEN 'buy'
        ELSE 'doesn''t buy'
    END AS ice_cream_status,
    v.hall,c.Vip_status,
    (
        CASE v.popcorn_size 
            WHEN 'small' THEN ci.small_popcorn_price
            WHEN 'medium' THEN ci.medium_popcorn_price
            WHEN 'large' THEN ci.large_popcorn_price
            ELSE 0 
        END 
        + CASE v.drink_size 
            WHEN 'small' THEN ci.small_drink_price
            WHEN 'medium' THEN ci.medium_drink_price
            WHEN 'large' THEN ci.large_drink_price
            ELSE 0 
        END 
        + CASE v.ice_cream 
            WHEN 1 THEN ci.ice_cream_price
            ELSE 0 
        END 
        + CASE v.hall 
            WHEN 'vip' THEN ci.vip_ticket_price
            WHEN 'regular' THEN ci.regular_ticket_price
            ELSE 0 
        END
    ) AS total_payment,
    dbo.CalculateFinalPriceForCustomer(c.customer_id, (
        CASE v.popcorn_size 
            WHEN 'small' THEN ci.small_popcorn_price
            WHEN 'medium' THEN ci.medium_popcorn_price
            WHEN 'large' THEN ci.large_popcorn_price
            ELSE 0 
        END 
        + CASE v.drink_size 
            WHEN 'small' THEN ci.small_drink_price
            WHEN 'medium' THEN ci.medium_drink_price
            WHEN 'large' THEN ci.large_drink_price
            ELSE 0 
        END 
        + CASE v.ice_cream 
            WHEN 1 THEN ci.ice_cream_price
            ELSE 0 
        END 
        + CASE v.hall 
            WHEN 'vip' THEN ci.vip_ticket_price
            WHEN 'regular' THEN ci.regular_ticket_price
            ELSE 0 
        END
    )) AS final_price
FROM 
    dbo.Customers c 
    INNER JOIN dbo.Views v ON c.customer_id = v.customer_id 
    INNER JOIN dbo.Movies m ON v.movie_id = m.movie_id 
    INNER JOIN dbo.Branches b ON v.branch_id = b.branch_id 
    INNER JOIN dbo.Cinemas ci ON b.cinema_id = ci.cinema_id
where v.view_id=dbo.maxView()
GO

-- Procedure that adds the last view to the corresponding table of the cinema where the movie was watched
-- The Exec is in the trigger
CREATE OR ALTER PROCEDURE InsertIntoCorrectCinema
AS
BEGIN
    DECLARE @cinemaName NVARCHAR(255);

    -- Retrieve the cinema name from the view
    SELECT @cinemaName = cinema
    FROM view_details2;

    -- Insert into the corresponding cinema table
    IF @cinemaName = 'Lev Cinema'
    BEGIN
        INSERT INTO Cinema_Lev_Cinema (view_id, customer_id, [customer name], [movie], [cinema branch], cinema, popcorn_size, drink_size, ice_cream_status, hall, Vip_status, total_payment)
        SELECT view_id, customer_id, [customer name], [movie], [cinema branch], cinema, popcorn_size, drink_size, ice_cream_status, hall, Vip_status,final_price
        FROM view_details2;
    END
    ELSE IF @cinemaName = 'Cinema City'
    BEGIN
        INSERT INTO Cinema_Cinema_City (view_id, customer_id, [customer name], [movie], [cinema branch], cinema, popcorn_size, drink_size, ice_cream_status, hall, Vip_status, total_payment)
        SELECT view_id, customer_id, [customer name], [movie], [cinema branch], cinema, popcorn_size, drink_size, ice_cream_status, hall, Vip_status,final_price
        FROM view_details2;
    END
    ELSE IF @cinemaName = 'Hot Cinema'
    BEGIN
        INSERT INTO Cinema_Hot_Cinema (view_id, customer_id, [customer name], [movie], [cinema branch], cinema, popcorn_size, drink_size, ice_cream_status, hall, Vip_status, total_payment)
        SELECT view_id, customer_id, [customer name], [movie], [cinema branch], cinema, popcorn_size, drink_size, ice_cream_status, hall, Vip_status,final_price
        FROM view_details2;
    END
    ELSE IF @cinemaName = 'Movieland'
    BEGIN
        INSERT INTO Cinema_Movieland (view_id, customer_id, [customer name], [movie], [cinema branch], cinema, popcorn_size, drink_size, ice_cream_status, hall, Vip_status, total_payment)
        SELECT view_id, customer_id, [customer name], [movie], [cinema branch], cinema, popcorn_size, drink_size, ice_cream_status, hall, Vip_status, final_price
        FROM view_details2;
    END
END;
GO


-- If you want to see the updated table, you will need to execute the `SELECT` for the cinema where the movie was watched. (after you insert new "view" to table "views")
select * from Cinema_Cinema_City
go
select * from Cinema_Hot_Cinema
go
select * from Cinema_Lev_Cinema
go
select * from Cinema_Movieland
go

-------------------------------------------------------------------------------
-- trigger for insert new view to table "views", it update:

CREATE or alter TRIGGER after_insert_view
ON Views
AFTER INSERT
AS
BEGIN
    -- Update the number of watched movies and VIP status in Customers table
    UPDATE Customers
    SET 
        NumOfWatchedMovies = NumOfWatchedMovies + 1,
        Vip_status = CASE
                        WHEN NumOfWatchedMovies + 1 > 5 THEN 1
                        ELSE 0
                     END
    FROM Customers
    INNER JOIN inserted ON Customers.customer_id = inserted.customer_id;

    -- Update total views in Branches table
    UPDATE Branches
    SET total_views = total_views + 1
    FROM Branches
    INNER JOIN inserted AS i ON Branches.branch_id = i.branch_id;

    -- Update Views table for VIP customers (no charges for popcorn, drink, and ice cream)
    UPDATE Views
    SET popcorn_size = NULL,
        drink_size = NULL,
        ice_cream = NULL
    FROM Views
    INNER JOIN inserted AS i ON Views.view_id = i.view_id
    WHERE i.hall = 'VIP';

	--Execuate the Procedure that adds the last view to the corresponding table of the cinema where the movie was watched
	EXEC InsertIntoCorrectCinema;
END
GO

--for activate the trigger please insert new view
INSERT INTO Views (view_id, customer_id, movie_id, branch_id, popcorn_size, drink_size, ice_cream, hall) 
VALUES (885, 230, 1000014, 100026, 'medium', 'large', 1, 'regular')
go

select * from Views
go


-- Important note!!!:
-- You need to run the following again to see the changes:
-- Views: Most_Watched_Movies, Cinema_Summary
-- Functions: dbo.GetMoviesWatchedByCustomer, dbo.GetMostProfitableBranch
-- Procedures: GetCustomerViewDetails


-------------------------------------------------------------------------------------------------------------------

---------------------------Windows function------------------------------------------------------------------------

-- Showing the cumulative payment for each customer from all their views, ordered by the view_id (when they saw the movie, with smaller values indicating earlier views).
SELECT view_id, customer_id, "customer name", Vip_status, "movie", "cinema branch", "cinema", popcorn_size, drink_size, ice_cream_status, hall, total_payment, 
SUM(total_payment) OVER (PARTITION BY customer_id ORDER BY view_id) AS cumulative_payment, 
RANK() OVER (PARTITION BY customer_id ORDER BY view_id ) AS payment_rank
FROM view_details;


-- Showing the cumulative income for each genre of movies and the ranking of movies by income within each genre.
SELECT movie_id,name,director_id,genre_id,release_year,actor_id,income,
    RANK() OVER (PARTITION BY genre_id ORDER BY income DESC) AS income_rank,
    SUM(income) OVER (PARTITION BY genre_id ORDER BY release_year) AS cumulative_income,
    ROW_NUMBER() OVER (PARTITION BY genre_id ORDER BY release_year, income DESC) AS row_number
FROM Movies
GO
-------------------------------------------------------------------------------------------------------------------

-----------------------BackUp and Restore--------------------------------------------------------------------------

---Creating backups with date and time in the filename-------------------------
use master
go

CREATE or alter PROC proc_backup_database_date_time
    @P_Path nvarchar(100)
AS
BEGIN
    DECLARE @path_d_t nvarchar(100);
    SET @path_d_t = @P_Path + '\cinemas_sql_' 
        + convert(char(8), getdate(), 112) + '_' 
        + substring(convert(char(8), getdate(), 108), 1, 2) + '_' 
        + substring(convert(char(8), getdate(), 108), 4, 2) + '_' 
        + substring(convert(char(8), getdate(), 108), 7, 2) + '.bak';
    
    PRINT @path_d_t;

    BACKUP DATABASE Films TO DISK = @path_d_t;
END
GO

EXEC proc_backup_database_date_time 'C:\Users\Public';
GO

---Creating Restore of the backup-------------------------
IF EXISTS (SELECT name FROM sys.databases WHERE name = 'Films')
DROP DATABASE Films
GO

--You need to copy the path from C:\Users\Public because its changes every time (diffrent date and hour)
RESTORE DATABASE Films
FROM DISK = 'C:\Users\Public\cinemas_sql_20240804_11_14_50.bak'
GO

-------------------------------------------------------------------------------------------------------------------










